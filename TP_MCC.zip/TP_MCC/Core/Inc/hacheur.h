/*
 * hacheur.h
 *
 *  Created on: 9 nov. 2021
 *      Author: Laporte / Hanquiez
 */

/* Includes --------------------------------------------------------------*/
#include "console.h"

/* Variables ------------------------------------------------------------ */
extern TIM_HandleTypeDef htim1;

/* Function prototypes ---------------------------------------------------*/

