/*
 * hacheur.c
 *
 *  Created on: 9 nov. 2021
 *      Author: Laporte / Hanquiez
 */

/* Includes --------------------------------------------------------------*/
#include "hacheur.h"

/* Variables ------------------------------------------------------------ */

extern const uint8_t power_on[];
extern const uint8_t power_off[];
extern const uint8_t not_found[];

/* Functions ------------------------------------------------------------ */

/* - Function to start the chopper -
 * We only had to send a response to 1 for a very short time
 * */
void start(void){
	uart_write((uint8_t*) power_on,10);
	HAL_GPIO_WritePin(Start_Command_GPIO_Port, Start_Command_Pin, GPIO_PIN_RESET);
	HAL_Delay(1);
	HAL_GPIO_WritePin(Start_Command_GPIO_Port, Start_Command_Pin, GPIO_PIN_SET);
	HAL_Delay(1);
	HAL_GPIO_WritePin(Start_Command_GPIO_Port, Start_Command_Pin, GPIO_PIN_RESET);
	speed(50);
}

/* - Function to control the speed of the MCC -
 * We modify the value to put in the registers compared to our desired alpha in input
 * */
void speed(int alpha){
	int compare_value;
	compare_value = alpha*(1024-1)/100;
	__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, compare_value);
	__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, compare_value);

	HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
	HAL_TIMEx_PWMN_Start(&htim1, TIM_CHANNEL_1);
	HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_2);
	HAL_TIMEx_PWMN_Start(&htim1, TIM_CHANNEL_2);
}
